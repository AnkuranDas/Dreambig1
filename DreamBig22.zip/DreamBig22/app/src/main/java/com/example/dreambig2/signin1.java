package com.example.dreambig2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class signin1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signin1);
    }
}
